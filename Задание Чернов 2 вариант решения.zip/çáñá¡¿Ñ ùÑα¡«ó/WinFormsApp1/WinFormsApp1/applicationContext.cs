﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    internal class applicationDbContext : DbContext
    {

        private readonly string _connectionString;

        public DbSet<Product> Products { get; set; }//=> //Set<Product>(); //{ get; set; }

        public applicationDbContext(string serverName, string dataBaseName) //=> Database.EnsureCreated(); //(string ServerName, string dataBaseName) 
        {
            var ConStrBuilder = new SqlConnectionStringBuilder
            {
                DataSource = serverName,
                InitialCatalog = dataBaseName,
                TrustServerCertificate = true,
                IntegratedSecurity = true,
            };
            _connectionString = ConStrBuilder.ToString();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_connectionString);
            base.OnConfiguring(optionsBuilder);
            //optionsBuilder.UseSqlite("Database = Product.db");

        }
    }  
}
