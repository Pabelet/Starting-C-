using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Excel = Microsoft.Office.Interop.Excel;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        private readonly applicationDbContext _context;

        public Form1()
        {
            InitializeComponent();
            _context = new applicationDbContext(serverName: "(local)", dataBaseName: "ZadanieDb");
            _context.Database.EnsureCreated();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            _context.Products.Load();
            productBindingSource.DataSource = _context.Products.Local.ToBindingList();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            _context.SaveChanges();
        }

        //private void removeMaket(object sender, EventArgs e)
        // {
        //     for (int i=0; i < _context.Products.Local.Count; i++) { DataGridView.D }
        // }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            var service = productBindingSource.Current as Product;
            //int GridRowIndex = dataGridView1.CurrentCell.RowIndex;
            //var productToRemove = new Product { id = Id };
            //_context.Products.Remove(productToRemove);
            //var itemToRemove = _context.Products.Local.ToList();
            //_context.Remove(Product); 
            //_context.Products.ExecuteDelete<IDatabase, >;      
            _context.Products.Remove(service);
            _context.SaveChanges();
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            _context.Products.Load();
        }

        private void buttonExcel_Click(object sender, EventArgs e) //������ � ������
        {
            Excel.Application exApp = new Excel.Application();
            exApp.Workbooks.Add();
            Excel.Worksheet ws = (Excel.Worksheet)exApp.ActiveSheet;

            for (int i = 0; i <= dataGridView1.RowCount - 2;  i++)
            {
                for (int j = 0; j <= dataGridView1.ColumnCount - 1; j++)
                {
                    ws.Cells[i+1, j+1] = dataGridView1[j, i].Value.ToString();
                }
            }

            exApp.Visible = true;
        }
    }
}
